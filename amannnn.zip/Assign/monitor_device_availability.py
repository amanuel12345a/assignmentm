import os
import platform
import smtplib
import subprocess
import sys
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from config import SMTP_SERVER, SMTP_PORT, FROM_EMAIL, TO_EMAIL, SEND_EMAIL

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from enumerate_devices import enumerate_devices

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FILE = os.path.join(SCRIPT_DIR, "network_devices.csv")

EMAIL_SUBJECT_TEMPLATE = "Network Device Unavailable: {name} ({ip})"


def has_static_ip(address):
    return address not in ("DHCP", "None", "")


def ping_device(ip):
    flag = "-n" if platform.system().lower() == "windows" else "-c"
    timeout_flag = "-w" if platform.system().lower() == "windows" else "-W"
    try:
        result = subprocess.run(
            ["ping", flag, "2", timeout_flag, "1", ip],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def build_email(device, timestamp):
    name = device["Device Name"]
    ip = device["Device Address"]
    subject = EMAIL_SUBJECT_TEMPLATE.format(name=name, ip=ip)
    body = f"""Dear Network Administrator,

This is an automated notification that the following network device is currently unavailable:

Device Name: {name}
IP Address: {ip}
Last Checked: {timestamp}

Please investigate this issue at your earliest convenience.

Best regards,
Network Monitoring System"""
    return subject, body


def send_email(subject, body, dry_run=True):
    msg = MIMEMultipart()
    msg["From"] = FROM_EMAIL
    msg["To"] = TO_EMAIL
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    print("\n" + "=" * 70)
    print("DEVICE UNAVAILABLE NOTIFICATION EMAIL")
    print("=" * 70)
    print(f"From    : {FROM_EMAIL}")
    print(f"To      : {TO_EMAIL}")
    print(f"Subject : {subject}")
    print("-" * 70)
    print(body)
    print("=" * 70)

    if not SEND_EMAIL or not SMTP_SERVER:
        print("\n[DRY RUN] Email displayed (startup SMTP not configured / SEND_EMAIL unset).")
        return

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10) as server:
            server.send_message(msg)
        print("\nNotification email sent successfully.")
    except Exception as e:
        print(f"\nFailed to send email: {e}")


def main():
    devices = enumerate_devices(CSV_FILE)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    print("=" * 70)
    print("DEVICE AVAILABILITY MONITOR")
    print("=" * 70)
    header = f"{'Device Name':<14} {'Address':<18} {'Status':<10} {'OS':<14}"
    print(header)
    print("-" * len(header))

    unavailable = []
    for d in devices:
        address = d["Device Address"]
        if not has_static_ip(address):
            print(f"{d['Device Name']:<14} {address:<18} {'SKIPPED':<10} {d['OS']:<14}")
            continue
        online = ping_device(address)
        status = "ONLINE" if online else "OFFLINE"
        print(f"{d['Device Name']:<14} {address:<18} {status:<10} {d['OS']:<14}")
        if not online:
            unavailable.append(d)

    print("-" * len(header))
    print(f"Unavailable devices: {len(unavailable)}")

    dry_run = not bool(SMTP_SERVER)
    for device in unavailable:
        subject, body = build_email(device, timestamp)
        send_email(subject, body, dry_run=dry_run)


if __name__ == "__main__":
    main()