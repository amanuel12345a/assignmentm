import csv
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

from config import (
    HELPDESK_BASE_URL,
    HELPDESK_TOKEN,
    SMTP_SERVER,
    SMTP_PORT,
    FROM_EMAIL,
    TO_EMAIL,
    SEND_EMAIL,
)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FILE = os.path.join(SCRIPT_DIR, "network_devices.csv")


EMAIL_SUBJECT = "URGENT: Device Compromise Detected\u2014Immediate Attention Required"


def enumerate_devices(csv_path):
    devices = []
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            devices.append(row)
    return devices


def build_email_body(devices):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    device_lines = []
    for d in devices:
        device_lines.append(f"Device Name: {d['Device Name']}")
        device_lines.append(f"IP Address: {d['Device Address']}")

    device_section = "\n".join(device_lines)

    body = f"""Dear Stakeholders,

This is an automated alert to inform you that the following device(s) have been identified as compromised during the recent network scan:

{device_section}

Last Checked: {timestamp}

Immediate investigation and remediation are recommended to prevent further impact.

If you have any questions or require additional information, please contact the IT support team.

Best regards,
Network Monitoring System"""

    return body


def send_email(body, dry_run=True):
    msg = MIMEMultipart()
    msg["From"] = FROM_EMAIL
    msg["To"] = TO_EMAIL
    msg["Subject"] = EMAIL_SUBJECT
    msg.attach(MIMEText(body, "plain"))

    print("=" * 70)
    print("EMAIL ALERT")
    print("=" * 70)
    print(f"From    : {FROM_EMAIL}")
    print(f"To      : {TO_EMAIL}")
    print(f"Subject : {EMAIL_SUBJECT}")
    print("-" * 70)
    print(body)
    print("=" * 70)

    if dry_run or not SMTP_SERVER:
        print("\n[DRY RUN] SMTP not configured. Set SMTP_SERVER env var to send.")
        return

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10) as server:
            server.send_message(msg)
        print("\nEmail sent successfully.")
    except Exception as e:
        print(f"\nFailed to send email: {e}")


def is_static_ip(addr):
    return addr not in ("DHCP", "None", "")


def main():
    all_devices = enumerate_devices(CSV_FILE)
    compromised = [d for d in all_devices if is_static_ip(d["Device Address"])]
    body = build_email_body(compromised)
    dry_run = not bool(SMTP_SERVER)
    send_email(body, dry_run=dry_run)


if __name__ == "__main__":
    main()