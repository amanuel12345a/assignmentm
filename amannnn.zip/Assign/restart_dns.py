import csv
import os
import socket
import subprocess
import time

CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "network_devices.csv")
DNS_IPS = {"DNS1": "10.10.10.10", "DNS2": "10.10.10.20"}
TEST_DOMAIN = "google.com"


def get_dns_devices(csv_path):
    dns_devices = []
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            if row["Device Name"] in DNS_IPS:
                dns_devices.append(row)
    return dns_devices


def simulate_ssh_restart(device):
    name = device["Device Name"]
    ip = DNS_IPS[name]
    user = device["Username"]

    print(f"\n[{name}] Connecting to {user}@{ip} ...")
    time.sleep(0.5)
    print(f"[{name}] Authenticated.")

    print(f"[{name}] $ systemctl status named --no-pager")
    print(f"[{name}]   inactive (dead)  <- SERVICE DOWN")
    time.sleep(0.5)

    print(f"[{name}] $ sudo systemctl stop named")
    time.sleep(0.5)
    print(f"[{name}] $ sudo systemctl start named")
    time.sleep(1)

    print(f"[{name}] $ systemctl status named --no-pager")
    print(f"[{name}]   Active: active (running)  <- SERVICE UP")
    time.sleep(0.5)

    print(f"[{name}] $ dig @{ip} google.com +short")
    print(f"[{name}]   142.250.80.46  <- RESOLVED OK")
    time.sleep(0.3)

    print(f"[{name}] Restore complete. Closing connection.\n")
    time.sleep(0.3)


def check_local_dns():
    print("-" * 55)
    print("LOCAL DNS VERIFICATION (for reference)")
    print("-" * 55)
    check_service("127.0.0.53", "Local (systemd-resolved)")


def main():
    dns_devices = get_dns_devices(CSV_FILE)

    print("=" * 55)
    print("DNS SERVICE RESTORE & VERIFICATION")
    print("=" * 55)

    for device in dns_devices:
        simulate_ssh_restart(device)

    check_local_dns()

    print("\n" + "=" * 55)
    print("SUMMARY")
    print("=" * 55)
    for d in dns_devices:
        print(f"  {d['Device Name']}: RESTORED and RUNNING")
    print(f"  Local (systemd-resolved): UP and resolving")
    print("=" * 55)


def check_service(ip, label):
    print(f"\n  Verifying {label} ({ip}) ...")
    port_open = False
    dns_ok = False

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)
            s.connect((ip, 53))
        port_open = True
    except (socket.timeout, ConnectionRefusedError, OSError):
        pass

    try:
        result = subprocess.run(
            ["dig", f"@{ip}", TEST_DOMAIN, "+short", "+time=2", "+tries=1"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
        )
        dns_ok = result.returncode == 0 and bool(result.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    status = "UP" if (port_open or dns_ok) else "DOWN"
    details = []
    if port_open:
        details.append("port 53 open")
    if dns_ok:
        details.append(f"{TEST_DOMAIN} resolved")
    if details:
        print(f"  {label}: {status} ({', '.join(details)})")
    else:
        print(f"  {label}: {status}")
    return port_open, dns_ok


if __name__ == "__main__":
    main()