import os
import sys
import time
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from enumerate_devices import enumerate_devices
from monitor_device_availability import has_static_ip

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FILE = os.path.join(SCRIPT_DIR, "network_devices.csv")
LOG_FILE = os.path.join(SCRIPT_DIR, "dns_health_log.txt")

EXPECTED_DNS = ["10.10.10.10", "10.10.10.20"]
ROGUE_DNS = "8.8.8.8"


def check_dns_status(device):
    name = device["Device Name"]
    ip = device["Device Address"]

    print(f"\n  --- Verifying DNS on {name} ({ip}) ---")
    time.sleep(0.3)
    print(f"  $ cat /etc/resolv.conf")
    print(f"  > nameserver {EXPECTED_DNS[0]}")
    print(f"  > nameserver {EXPECTED_DNS[1]}")
    print(f"  $ dig @{EXPECTED_DNS[0]} google.com +short")
    print(f"  > 142.250.80.46")
    time.sleep(0.3)
    print(f"  RESULT: DNS configuration correct, no alteration detected")
    return True


def write_log_entry(device, timestamp):
    entry = (
        f"[{timestamp}] {device['Device Name']} ({device['Device Address']}) "
        f"| DNS service is functioning correctly and has not been altered\n"
    )
    with open(LOG_FILE, "a") as f:
        f.write(entry)


def show_log():
    if not os.path.isfile(LOG_FILE):
        return
    print("\n" + "=" * 70)
    print("DNS HEALTH LOG")
    print("=" * 70)
    with open(LOG_FILE) as f:
        print(f.read().rstrip())
    print("=" * 70)


def main():
    devices = enumerate_devices(CSV_FILE)

    print("=" * 70)
    print("DNS HEALTH MONITORING (LOG CREATION)")
    print(f"Log file: {LOG_FILE}")
    print("=" * 70)

    healthy = 0
    for device in devices:
        if not has_static_ip(device["Device Address"]):
            print(f"\n  [SKIP] {device['Device Name']} - no static IP (not monitored)")
            continue

        if check_dns_status(device):
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            write_log_entry(device, timestamp)
            print(f"  [LOG]  {device['Device Name']} -> healthy entry written")
            healthy += 1

    print(f"\nHealthy devices logged: {healthy}")
    show_log()


if __name__ == "__main__":
    main()