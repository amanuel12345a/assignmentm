import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_FILE = os.path.join(SCRIPT_DIR, ".env")


def load_env():
    if os.path.isfile(ENV_FILE):
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()

                if (
                    line
                    and not line.startswith("#")
                    and "=" in line
                ):
                    key, _, value = line.partition("=")

                    if key.strip() not in os.environ:
                        os.environ[key.strip()] = value.strip()


load_env()

HELPDESK_BASE_URL = os.environ.get("HELPDESK_BASE_URL", "http://localhost:8080")
HELPDESK_TOKEN = os.environ.get("HELPDESK_TOKEN", "")
TICKET_URL = os.environ.get("TICKET_URL", "http://localhost:8080/tickets")

SMTP_SERVER = os.environ.get("SMTP_SERVER", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "1025"))
FROM_EMAIL = os.environ.get("FROM_EMAIL", "nms@company.local")
TO_EMAIL = os.environ.get("TO_EMAIL", "stakeholders@company.local")
SEND_EMAIL = os.environ.get("SEND_EMAIL", "false").lower() in (
    "1",
    "true",
    "yes",
)

VYOS_SSH_HOST = os.environ.get("VYOS_SSH_HOST", "10.10.10.1")
VYOS_SSH_PORT = int(os.environ.get("VYOS_SSH_PORT", "22"))
VYOS_USERNAME = os.environ.get("VYOS_USERNAME", "vyos")
VYOS_PASSWORD = os.environ.get("VYOS_PASSWORD", "")