import csv
import os
import re
import shutil
import subprocess
import sys
from config import (
        VYOS_SSH_HOST,
        VYOS_SSH_PORT,
        VYOS_USERNAME,
        VYOS_PASSWORD,
    )

CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "network_devices.csv")
IP_PATTERN = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def enumerate_devices(csv_path):
    devices = []
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            devices.append(row)

    dhcp_rows = [d for d in devices if d["Device Address"] == "DHCP"]
    if not dhcp_rows:
        return devices

    try:
        leases = get_dhcp_leases()
    except Exception as exc:
        print(
            f"[WARN] DHCP lookup failed; {len(dhcp_rows)} DHCP device(s) "
            f"left as 'DHCP' and will be skipped: {exc}",
            file=sys.stderr,
        )
        return devices

    for row in dhcp_rows:
        resolved = leases.get(row["Device Name"].lower())
        if resolved:
            row["Device Address"] = resolved
        else:
            print(
                f"[WARN] No DHCP lease found for '{row['Device Name']}'; "
                f"leaving as 'DHCP' (it will be skipped).",
                file=sys.stderr,
            )
    return devices


def print_devices(devices):
    header = f"{'Device ID':<12} {'Name':<14} {'Address':<16} {'Subnet Mask':<18} {'Location':<12} {'Port':<6} {'OS':<14}"
    print("=" * len(header))
    print(header)
    print("-" * len(header))
    for d in devices:
        print(
            f"{d['Device ID']:<12} {d['Device Name']:<14} {d['Device Address']:<16} "
            f"{d['Subnet Mask']:<18} {d['Location']:<12} {d['Access Port']:<6} {d['OS']:<14}"
        )
    print("=" * len(header))
    print(f"Total devices: {len(devices)}")


def get_dhcp_leases():
    command = "show dhcp server leases"

    if shutil.which("sshpass") and VYOS_PASSWORD:
        output = _run_leases_via_sshpass(command)
    else:
        output = _run_leases_via_paramiko(command)

    return parse_leases(output)


def _run_leases_via_sshpass(command):
    argv = ["sshpass", "-p", VYOS_PASSWORD]
    argv += [
        "ssh",
        "-o", "StrictHostKeyChecking=no",
        "-o", "ConnectTimeout=5",
        "-p", str(VYOS_SSH_PORT),
        f"{VYOS_USERNAME}@{VYOS_SSH_HOST}",
        command,
    ]
    try:
        result = subprocess.run(
            argv, capture_output=True, text=True, timeout=15
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"SSH to {VYOS_USERNAME}@{VYOS_SSH_HOST}:{VYOS_SSH_PORT} timed out") from exc
    if result.returncode != 0:
        raise RuntimeError(
            f"SSH to {VYOS_USERNAME}@{VYOS_SSH_HOST}:{VYOS_SSH_PORT} failed: "
            f"{(result.stderr or '').strip() or f'exit code {result.returncode}'}"
        )
    return result.stdout


def _run_leases_via_paramiko(command):
    try:
        import paramiko
    except ImportError as exc:
        raise RuntimeError(
            "Cannot query VyOS DHCP leases: neither `sshpass` nor `paramiko` is "
            "available. Install one of them:\n"
            "  sudo apt install sshpass\n"
            "  pip install paramiko\n"
            "and set VYOS_PASSWORD in .env"
        ) from exc

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=VYOS_SSH_HOST,
            port=int(VYOS_SSH_PORT),
            username=VYOS_USERNAME,
            password=VYOS_PASSWORD,
            timeout=10,
            allow_agent=False,
            look_for_keys=False,
        )
        _, stdout, stderr = client.exec_command(command, timeout=10)
        output = stdout.read().decode(errors="replace")
        errors = stderr.read().decode(errors="replace").strip()
        if not output.strip() and errors:
            raise RuntimeError(
                f"SSH to {VYOS_USERNAME}@{VYOS_SSH_HOST}:{VYOS_SSH_PORT} failed: {errors}"
            )
        return output
    finally:
        client.close()


def parse_leases(output):
    leases = {}
    for line in output.splitlines():
        tokens = line.split()
        if len(tokens) < 2:
            continue
        ip, hostname = tokens[0], tokens[-1]
        if not IP_PATTERN.match(ip):
            continue
        if not hostname or hostname.lower() in ("hostname",):
            continue
        leases[hostname.lower()] = ip
    return leases


def main():
    devices = enumerate_devices(CSV_FILE)
    print_devices(devices)


if __name__ == "__main__":
    main()
