import socket
import subprocess
import sys

DNS_SERVERS = [
    ("DNS1", "10.10.10.10"),
    ("DNS2", "10.10.10.20"),
]
TEST_DOMAIN = "google.com"


def check_port(ip, port=53, timeout=2):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((ip, port))
        return True
    except (socket.timeout, ConnectionRefusedError, OSError):
        return False


def query_dns(ip, domain):
    try:
        result = subprocess.run(
            ["dig", f"@{ip}", domain, "+short", "+time=2", "+retry=0", "+tries=1"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
        )
        return result.returncode == 0 and bool(result.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def main():
    print("=" * 55)
    print("DNS SERVICE VERIFICATION (Pre-Remediation)")
    print("=" * 55)
    print(f"{'Server':<10} {'Address':<16} {'Port 53':<12} {'DNS Query':<12}")
    print("-" * 55)

    all_down = []
    for name, ip in DNS_SERVERS:
        port_open = check_port(ip)
        dns_resolved = query_dns(ip, TEST_DOMAIN) if port_open else False

        port_status = "OPEN" if port_open else "CLOSED"
        query_status = "OK" if dns_resolved else "FAIL"

        print(f"{name:<10} {ip:<16} {port_status:<12} {query_status:<12}")

        if not port_open and not dns_resolved:
            all_down.append(name)

    print("-" * 55)

    if all_down:
        status = ", ".join(all_down)
        print(f"CONCLUSION: DNS service is DOWN on: {status}")
    else:
        print("CONCLUSION: DNS service is operational.")

    print("=" * 55)

    if all_down:
        sys.exit(1)


if __name__ == "__main__":
    main()