import os
import platform
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from enumerate_devices import enumerate_devices

CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "network_devices.csv")

EXPECTED_DNS = {"10.10.10.10", "10.10.10.20"}
TEST_DOMAIN = "google.com"

def ping_device(ip):
    if ip in ("DHCP", "None", ""):
        return "SKIPPED"
    flag = "-n" if platform.system().lower() == "windows" else "-c"
    timeout_flag = "-w" if platform.system().lower() == "windows" else "-W"
    try:
        result = subprocess.run(
            ["ping", flag, "2", timeout_flag, "1", ip],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
        return "ONLINE" if result.returncode == 0 else "OFFLINE"
    except subprocess.TimeoutExpired:
        return "OFFLINE"


def get_current_nameservers():
    try:
        with open("/etc/resolv.conf") as f:
            servers = {line.split()[1] for line in f if line.startswith("nameserver")}
        return servers
    except FileNotFoundError:
        return set()


def resolve_via_ns(domain, nameserver):
    try:
        subprocess.run(
            ["dig", f"@{nameserver}", domain, "+short", "+time=2"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=True,
            timeout=5,
        )
        return True
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        try:
            subprocess.run(
                ["nslookup", "-timeout=2", domain, nameserver],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            return True
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            return False


def verify_dns():
    current_dns = get_current_nameservers()
    rogue = current_dns - EXPECTED_DNS
    dns1_status = "UP" if resolve_via_ns(TEST_DOMAIN, "10.10.10.10") else "DOWN"
    dns2_status = "UP" if resolve_via_ns(TEST_DOMAIN, "10.10.10.20") else "DOWN"

    print("\n" + "=" * 70)
    print("DNS VERIFICATION")
    print("=" * 70)
    print(f"Current nameserver(s) : {', '.join(sorted(current_dns)) if current_dns else 'N/A'}")
    print(f"Expected nameservers   : {', '.join(sorted(EXPECTED_DNS))}")
    if rogue:
        print(f"WARNING: Rogue DNS detected  -> {', '.join(sorted(rogue))}")
    else:
        print("No rogue DNS detected.")
    print(f"DNS1 (10.10.10.10)     : {dns1_status}")
    print(f"DNS2 (10.10.10.20)     : {dns2_status}")
    return current_dns, rogue


def get_affected_devices(csv_path=None):
    if csv_path is None:
        csv_path = CSV_FILE
    devices = enumerate_devices(csv_path)
    affected = [d for d in devices if d["Device Address"] not in ("DHCP", "None", "")]
    return affected


def main():
    devices = enumerate_devices(CSV_FILE)

    print("\n" + "=" * 70)
    print("DEVICE STATUS CHECK")
    print("=" * 70)
    header = f"{'Device Name':<14} {'Address':<18} {'Ping':<10} {'OS':<14}"
    print(header)
    print("-" * len(header))

    for d in devices:
        address = d["Device Address"]
        status = ping_device(address)
        print(f"{d['Device Name']:<14} {address:<18} {status:<10} {d['OS']:<14}")

    print("-" * len(header))

    verify_dns()
    print("=" * 70)


if __name__ == "__main__":
    main()